import blogs from "../../../data/news.json"
import Footer from "@/Component/Footer";
import React from "react";
import { DevBundlerService } from "next/dist/server/lib/dev-bundler-service";
import Category from "@/Component/Category";

const categories = ["News", "Entertainment", "Sports", "Lifestyle", "Food", "Politics", "Spiritual", "Business"];

export async function generateStaticParams() {
  // Generate static paths for all categories
  return categories.map((category) => ({
    category: category,  // category is the dynamic parameter in the route
  }));
}

export default function CategoryPost({ params }) {
    const { category } = React.use(params);
  
    return (
        <div className="w-full bg-white h-full px-20">
            <Category category={category}/>
        </div>
    )
}
