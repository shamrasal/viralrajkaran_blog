"use client"
import img from "next/image";
import blogs from "./../data/news.json"
import Footer from "@/Component/Footer";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function Home() {
  const [index, setIndex] = useState(0)

  const router = useRouter();

  // Automatically slide every 2 seconds
  useEffect(() => {
    const intervalId = setInterval(nextImage, 2500); // Change image every 2 seconds
    return () => clearInterval(intervalId); // Clear interval on component unmount
  }, []);
  
  const goToHomePage = ()=>{
    router.replace("/")
  }
  
  const goToViewPostRoute = (id)=>{
    router.push(`/posts/${id}`)
  }

  const nextImage = () => {
    setIndex((prevIndex) => (prevIndex + 1) % 5)
  }

  const prevImage = () => {
    setIndex((prevIndex) => (prevIndex - 1 + 5) % 5)
  }
  const lastestBlog = blogs.length > 0 ? blogs[0] : {}
  
  return (
    <div className="w-full bg-white h-full px-20">
      
      <div>
        <div className="relative h-[65vh] w-full overflow-hidden">
          <div
            className="flex transition-all duration-700 ease-in-out"
            style={{ transform: `translateX(-${index * 100}%)` }}
          >
            {blogs.map((src, i) => (
              <div key={i} className="w-full flex-shrink-0">
                <img
                  src={i%2 == 0 ? "/1.jpg" : "/2.jpg"}
                  alt={`sadhu ${i + 1}`}
                  width={1920} // Set width
                  height={1080} // Set height
                  className="w-full h-auto cursor-pointer"
                />
              </div>
            ))}
          </div>
          {/* Carousel Controls */}
          <button
            onClick={prevImage}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-gray-700 text-white p-2 rounded-full"
          >
            &#10094;
          </button>
          <button
            onClick={nextImage}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-gray-700 text-white p-2 rounded-full"
          >
            &#10095;
          </button>
      </div>
      </div>
      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 mt-4">
        <div className="sm:col-span-1 md:col-span-2">
          <div className="mb-10">
            <div className="text-4xl font mt-3 my-3">Trending Topic</div>
            <img className="cursor-pointer" height={500} width={1100} src={"/1.jpg"} title="sadhu" alt="sadhu"/>
            <div className="text-4xl mt-3">{lastestBlog.title}</div>
            <div>{lastestBlog.category}</div>
            <div className="text-wrap my-3">{lastestBlog.content.length > 500 ? lastestBlog.content.slice(0,500) + "..." : lastestBlog.content }</div>
          </div>
          <div className="text-4xl font mt-3 my-3">Viral Topic</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols- gap-4">
            {
              blogs.length > 0 && 
                blogs.map((post,postIndex)=>{
                  if(postIndex != 0  && postIndex <= 10 ){
                    return(
                      <div key={postIndex} className="mt-4">
                        <img onClick={()=>goToViewPostRoute(post.id)} className="cursor-pointer hover:scale-102 hover:transition-all duration-300 ease-in-out" height={500} width={550} src={postIndex%2 == 0 ? "/1.jpg" : "/2.jpg"} title="sadhu" alt="sadhu"/>
                        <div className="text-2xl mt-3 hover:text-blue-500 transition-colors duration-300 ease-in-out">{post.title.length > 30 ? post.title.slice(0,30) + "..." : post.title }</div>
                        <div className="my-2 text-gray-500">{post.category}</div>
                        <div className="text-wrap">{post.content.length > 500 ? post.content.slice(0,500) + "..." : post.content }</div>
                        <div onClick={()=>goToViewPostRoute(post.id)} className="my-2 text-blue-600 cursor-pointer">Click here to read</div>
                      </div>
                    )
                  }
                })
            }
          </div>
        </div>
        <div className="mb-4">
          <div className="text-4xl font mt-3 my-3">Readers Choice</div>
          {
            blogs.length > 0 && 
              blogs.map((post,postIndex)=>{
                if(postIndex != 0 && postIndex <= 10 ){
                  return(
                    <div key={postIndex} className="">
                      <img onClick={()=>goToViewPostRoute(post.id)} className="cursor-pointer hover:scale-103 hover:transition-all duration-300 ease-in-out" height={500} width={550} src={postIndex % 2 == 0 ? "/1.jpg" : "/2.jpg"} title="sadhu" alt="sadhu"/>
                      <div className="text-2xl mt-3 hover:text-blue-500 transition-colors duration-300 ease-in-out">{post.title.length > 30 ? post.title.slice(0,30) + "..." : post.title }</div>
                      <div className="my-2 text-gray-500">{post.category}</div>
                      <div className="text-wrap">{post.content.length > 500 ? post.content.slice(0,500) + "..." : post.content }</div>
                      <div onClick={()=>goToViewPostRoute(post.id)} className="my-2 text-blue-600 cursor-pointer">Click here to read</div>
                    </div>
                  )
                }
              })
          }
        </div>
        <div className="sm:col-span-1 md:col-span-1 bg-gray-100 p-2 pb-4 mb-4">
          Advertise
        </div>
      </div>
    </div>
  );
}
