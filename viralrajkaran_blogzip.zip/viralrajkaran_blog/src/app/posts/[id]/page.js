import React from "react";
import blogs from "../../../data/news.json"
import PostId from "@/Component/PostId";

export async function generateStaticParams() {
    // Generate static paths for all categories
    return blogs.map((post) => ({
      id: post.id ? post.id.toString() : "",  // category will be the dynamic parameter
    }));
  }

const Post = ({ params }) => {
    console.log(params)
    const { id } = React.use(params); // Unwrap the params
    
    return (
        <PostId id={id}/>
    );
};

export default Post;
