"use client"
import React,{useState} from 'react'

export default function Footer() {
    const [subcribeEmailId,setSubscribedEmailId] = useState("")

    return (
        <div className='w-full h-full bg-[RGB(225,250,191)] p-20 mt-10'> 
            <div>
                <div className="text-4xl font-serif">VIRAL BLOGS</div>
                <span className="absolute left-0 bottom-0 w-full h-1 bg-blue-500 transform scale-x-0 hover:scale-x-100 transition-transform duration-300 ease-in-out"></span>
            </div>
            <div className='grid sm:grid-cols-2 md:grid-cols-3'>
                <div className='col-span-1 mt-10'>
                    <div className="sm:text-sm md:text-2xl font-bold">JOIN OUR CHANNEL</div>
                    <div className="my-2">GET UNLIMITED INFORMATION IN MARATHI</div>
                    <input placeholder='Enter your email id' className='sm:w-md md:w-lg text-gray-900 my-3 border border-gray-300 py-2 px-4 rounded hover:bg-white focus:outline-none focus:ring-2 focus:ring-[RGB(66,74,50)]' title='Email id' value={subcribeEmailId} onChange={(e)=>e.target.value}/>
                    <button className="cursor-pointer my-3 sm:w-md md:w-lg bg-[RGB(66,74,50)] text-white py-2 px-4 rounded-2xl text-lg font-semibold transition-all duration-300 ease-in-out transform hover:scale-105 hover:bg-[RGB(66,74,50)] hover:shadow-lg">{"JOIN NOW"}</button>
                </div>
                <div className=' col-span-1 sm:col-span-2 md:col-span-2 '>
                    <div className='grid sm:grid-cols-2 md:grid-cols-3 mt-16 sm:text-right md:text-left '>
                        <div className='sm:mb-20'>
                            <div className="text-2xl mb-4">Category</div>
                            <div className="cursor-pointer">News</div>
                            <div className="cursor-pointer">Entertainment</div>
                            <div className="cursor-pointer">Spritual</div>
                        </div>
                        <div className='sm:mb-20'>
                            <div className="text-2xl mb-4">Usefull links</div>
                            <div className="cursor-pointer">Terms & Conditions</div>
                            <div className="cursor-pointer">Privacy Policy</div>
                        </div>
                        <div className='sm:mb-20'>
                            <div className="text-2xl mb-4">Company</div>
                            <div className="cursor-pointer">About Us </div>
                            <div className="cursor-pointer">Contact Us</div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="pt-20 text-center">© 2025 All rights are reserved by shamesh. </div>
        </div>
    )
}
