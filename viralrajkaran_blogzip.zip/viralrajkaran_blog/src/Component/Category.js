"use client"
import img from "next/image";
import blogs from "../data/news.json"
import Footer from "@/Component/Footer";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { DevBundlerService } from "next/dist/server/lib/dev-bundler-service";


export default function Category({category}) {
    const [index, setIndex] = useState(0)
    const [filteredBlogs, setFilteredBlogs] = useState([]);
    const [post, setPost] = useState([]);
    const [latestBlog, setLatestBlog] = useState({});

    const router = useRouter();

    // Automatically slide every 2 seconds
    useEffect(() => {
        const intervalId = setInterval(nextImage, 2500); // Change image every 2 seconds
        return () => clearInterval(intervalId); // Clear interval on component unmount
    }, []);

    useEffect(() => {
        if (category) {
            debugger
            const filtered = blogs.filter(blog => blog.category.toLowerCase() === category.toLowerCase());
            setFilteredBlogs(filtered);

            if (filtered.length > 0) {
                setLatestBlog(filtered[0]); // First post as the latest post
            }
        }
    }, [category]);
    
    const nextImage = () => {
        setIndex((prevIndex) => (prevIndex + 1) % 5)
    }

    const prevImage = () => {
        setIndex((prevIndex) => (prevIndex - 1 + 5) % 5)
    }

    const goToViewPostRoute = (id)=>{
        router.push(`/posts/${id}`)
    }

    return (
        <div className="w-full bg-white h-full px-20">
            <div className="grid grid-cols-3 gap-4 mt-4">
            {
                filteredBlogs.length == 0 ?
                    <div className="col-span-2">
                        <div className="text-wrap w-[100vw] h-[100vh] p-20">{"There is no blog data for this category"}</div>
                    </div>
                :
                    <div className="col-span-2">
                        <div className="text-4xl font mt-3 my-3">Searched Results</div>
                        <div className="grid grid-cols-2 gap-4">
                        {
                            filteredBlogs && filteredBlogs.length > 0 && 
                                filteredBlogs.map((post,postIndex)=>{
                                    if(postIndex != 0  && postIndex <= 10 ){
                                    return(
                                        <div key={postIndex} className="mt-4">
                                        <img onClick={()=>goToViewPostRoute(post.id)} className="cursor-pointer hover:scale-102 hover:transition-all duration-300 ease-in-out" height={500} width={550} src={postIndex%2 == 0 ? "/1.jpg" : "/2.jpg"} title="sadhu" alt="sadhu"/>
                                        <div className="text-2xl mt-3 hover:text-blue-500 transition-colors duration-300 ease-in-out">{post.title.length > 30 ? post.title.slice(0,30) + "..." : post.title }</div>
                                        <div className="my-2 text-gray-500">{post.category}</div>
                                        <div className="text-wrap">{post.content.length > 500 ? post.content.slice(0,500) + "..." : post.content }</div>
                                        <div onClick={()=>goToViewPostRoute(post.id)} className="my-2 text-blue-600 cursor-pointer">Click here to read</div>
                                        </div>
                                    )
                                    }
                                })
                        }
                        </div>
                    </div>
            }
            <div className="mb-4">
                <div className="text-4xl font mt-3 my-3">Readers Choice</div>
                {
                    blogs && blogs.length > 0 && 
                        blogs.map((post,postIndex)=>{
                        if(postIndex != 0 && postIndex <= 10 ){
                            return(
                            <div key={postIndex} className="">
                                <img onClick={()=>goToViewPostRoute(post.id)} className="cursor-pointer hover:scale-103 hover:transition-all duration-300 ease-in-out" height={500} width={550} src={postIndex % 2 == 0 ? "/1.jpg" : "/2.jpg"} title="sadhu" alt="sadhu"/>
                                <div className="text-2xl mt-3 hover:text-blue-500 transition-colors duration-300 ease-in-out">{post.title.length > 30 ? post.title.slice(0,30) + "..." : post.title }</div>
                                <div className="my-2 text-gray-500">{post.category}</div>
                                <div className="text-wrap">{post.content.length > 500 ? post.content.slice(0,500) + "..." : post.content }</div>
                                <div onClick={()=>goToViewPostRoute(post.id)} className="my-2 text-blue-600 cursor-pointer">Click here to read</div>
                            </div>
                            )
                        }
                    })
                }
            </div>
            </div>
        </div>
    )
}



