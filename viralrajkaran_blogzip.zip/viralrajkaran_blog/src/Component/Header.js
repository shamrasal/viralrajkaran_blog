"use client"
import { useRouter } from 'next/navigation';
import React from 'react'

export default function Header() {

    const router = useRouter();
      
    const goToHomePage = ()=>{
        router.replace("/")
    }

    const goToCategoryPosts = (category)=>{
        router.replace(`/category/${category}`)
    }

    return (
        <div>
            <header className="flex justify-between items-center py-4 border-b">
                <button className="px-4 text-lg font-semibold"></button>
                <h1 onClick={()=>goToHomePage()} className="text-4xl font-bold cursor-pointer">Los Angeles Times</h1>
                <div>
                    {/* <button className="bg-blue-600 text-white px-4 py-2 rounded-md mr-2">
                    Subscribe
                    </button>
                    <button className="border px-4 py-2 rounded-md">Log In</button> */}
                </div>
            </header>
            <div className="row mb-8  bg-[RGB(112,117,97)]">
                <nav className="flex sm:scroll-smooth justify-center space-x-12 text-gray-700 py-3 border-b">
                    {["News","Entertainment", "Sports", "Lifestyle", "Food", "Politics", "Spritual", "Business"].map((item) => (
                    <a onClick={()=>goToCategoryPosts(item)} key={item} href="#" className="hover:underline text-white">
                        {item}
                    </a>
                    ))}
                </nav>
            </div>
        </div>
    )
}
