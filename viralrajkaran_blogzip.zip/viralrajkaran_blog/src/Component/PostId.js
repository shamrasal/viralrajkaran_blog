"use client"
import img from "next/image";
import blogs from "../data/news.json"
import Footer from "@/Component/Footer";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { DevBundlerService } from "next/dist/server/lib/dev-bundler-service";

export default function PostId({id}) {

    const router = useRouter();

    // Get the `id` from the URL params
    const [post, setPost] = useState(null);

    useEffect(() => {
        if (id) {
            if(blogs.length > 0 ){
                blogs.map((blog)=>{
                    if(blog.id == id){
                        setPost(blog)
                    }
                })
            }
        }
    }, [id]);

    if (!post) {
        return <p>Post not found.</p>;
    }

    const goToViewPostRoute = (id)=>{
        router.push(`/posts/${id}`)
        }
    
    return (
        <div className="bg-white mx-auto p-7">
            <div className="grid grid-cols-4 gap-4 mt-4 px-5">
                <div className="col-span-3 px-5">
                    <img height={500} width={1200} src={"/1.jpg"} title="sadhu" alt="sadhu"/>
                    <div className="text-4xl mt-3">{post.title}</div>
                    <div className="text-gray-500 my-2">{post.category} | {post.date}</div>
                    <div className="text-wrap my-3">{post.content}</div>
                </div>
                <div className="">
                    {
                        blogs.length > 0 && 
                            blogs.map((blogPost,postIndex)=>{
                                if(postIndex <= 5 && post.id != blogPost.id ){
                                    return(
                                    <div key={postIndex} className="">
                                        <img  onClick={()=>goToViewPostRoute(blogPost.id)} className="cursor-pointer hover:scale-103 hover:transition-all duration-300 ease-in-out" height={500} width={550} src={postIndex % 2 == 0 ? "/1.jpg" : "/2.jpg"} title="sadhu" alt="sadhu"/>
                                        <div className="text-2xl mt-3 hover:text-blue-500 transition-colors duration-300 ease-in-out">{blogPost.title}</div>
                                        <div className="my-2 text-gray-500">{blogPost.category}</div>
                                        <div className="text-wrap">{blogPost.content.length > 200 ? blogPost.content.slice(0,200) + "..." : blogPost.content }</div>
                                        <div onClick={()=>goToViewPostRoute(blogPost.id)} className="my-2 text-blue-600 cursor-pointer">Click here to read</div>
                                    </div>
                                    )
                                }
                            })
                    }
                </div>
            </div>
        </div>
    )
}
